const express = require('express');
const app = express();
const PORT = 3009;

const maytapi = require('maytapi');
const maytapiClient = new maytapi.Client('YOUR_API_KEY');
// Replace 'YOUR_API_KEY' with your actual Maytapi API key

app.use(express.json());

// Endpoint for handling incoming messages
app.post('/message', (req, res) => {
  const message = req.body.message;
  const recipientNumber = req.body.recipientNumber;
  
  // Process the user's message and generate a response
  let response;
  if (message === 'hi') {
    response = {
      text: 'How may I help you? Press 1 for sales or press 2 for other queries.',
      options: ['1', '2']
    };
  } else if (message === '1') {
    response = {
      text: 'Sales team will contact you later. If you have any other questions, press 1 for yes or press 2 for no.',
      options: ['1', '2']
    };
  } else if (message === '2') {
    response = {
      text: 'Our team will contact you later. Thank you! If you have any other questions, press 1 for yes or press 2 for no.',
      options: ['1', '2']
    };
  } else if (message === '1' || message === '2') {
    response = {
      text: 'Our team will contact you later. Thank you!',
      options: []
    };
  } else {
    response = {
      text: 'I\'m sorry, I didn\'t understand. Can you please provide a valid input?',
      options: []
    };
  }
  
  // Send the chatbot's response to Maytapi
  maytapiClient.sendMessage(recipientNumber, response.text)
    .then(() => {
      console.log('Message sent successfully');
      res.json(response);
    })
    .catch((error) => {
      console.error('Error sending message:', error);
      res.status(500).json({ error: 'Failed to send message' });
    });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
